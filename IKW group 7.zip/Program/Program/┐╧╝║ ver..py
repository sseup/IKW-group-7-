import cv2
import mediapipe as mp
import numpy as np
import time
# import pyautogui
from pynput.keyboard import Key, Controller
from pynput.mouse import Button,Controller
import pynput
from PIL import ImageFont, ImageDraw, Image
from voicetyper import *
# import keyboard

'''
@다운로드
pip install opencv-python
pip install mediapipe
pip install numpy
pip install time
pip install pyautogui
pip install pynput
pip install pillow

@한글 폰트 받기
https://drive.google.com/file/d/1i6HUWtxaXfXEv-mtKW5e_2wDo45Qh0bN/view

'''

def draw_rec(img):
    cv2.rectangle(img,(50,180),(150,230),(255,0,0),2)
    cv2.rectangle(img,(170,180),(270,230),(255,0,0),2)
    cv2.rectangle(img,(290,180),(390,230),(255,0,0),2)
    cv2.rectangle(img,(410,180),(510,230),(255,0,0),2)
    cv2.rectangle(img,(410,180),(510,230),(255,0,0),2)
    cv2.rectangle(img,(770,180),(990,280),(255,0,0),2)
    cv2.rectangle(img,(1010,180),(1230,280),(255,0,0),2)

#Program 까지의 경로를 적으시오 \ 아니고 / 입니다. 그냥 슬래쉬
path ="C:/Users/82106/Desktop/Program/Program"

#PIL(pillow) 폰트
font = ImageFont.truetype('{}/fonts/SCDream6.otf'.format(path), 20)

#pynput keyboard 쓰려고 만든거
keyboard = pynput.keyboard.Controller()
mouse_drag = pynput.mouse.Controller()

#최대 손 개수
max_num_hands = 2

#안쓰므로 지워도 무방할듯(?)
gesture = {
    0:'fist', 1:'Mouse', 2:'two', 3:'three', 4:'four', 5:'five',
    6:'six', 7:'rock', 8:'spiderman', 9:'yeah', 10:'ok',
}
rps_gesture = {0:'Keyboard'}

# MediaPipe hands model 미디어파이프 그리기 위한 유틸
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

hands = mp_hands.Hands(
    max_num_hands=max_num_hands,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5)

# Gesture recognition model 인식 모델 파일
file = np.genfromtxt('{}/gesture.train.csv'.format(path), delimiter=',')
angle = file[:,:-1].astype(np.float32)
label = file[:, -1].astype(np.float32)
knn = cv2.ml.KNearest_create()
knn.train(angle, cv2.ml.ROW_SAMPLE, label)


#카메라
cap = cv2.VideoCapture(0)

#카메라 해상도 출력
w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
print(w, h) # 640, 480

#해상도 설정 
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)


#keyboard 그리기 x,y 초기화 kb = keyboard
kb_start_x = 50
kb_start_y = 300
kb_end_x = 150
kb_end_y = 400
kb_text_x=80
kb_text_y=350
# start end 차이 x,y 각각 +50
# start x 랑 text x 차이 15 
# start y 랑 text y 차이 35
# end x 랑 다음 start x 랑 차이 20
# end y랑 다음 밑에 

#터치 감도  default 40
touch_sensitivity = 40
#추가 터치 감도
touch_sensitivity_plus = 20

#키 인덱스
            #ENG
keyboard_keys = [["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
                  ["a", "s", "d", "f", "g", "h", "j", "k", "l", ";"],
                  ["z", "x", "c", "v", "b", "n", "m", ",", ".", "/"]]
            #KOR
keyboard_keys_KOR = [["ㅂ", "ㅈ", "ㄷ", "ㄱ", "ㅅ", "ㅛ", "ㅕ", "ㅑ", "ㅐ", "ㅔ"],
                  ["ㅁ", "ㄴ", "ㅇ", "ㄹ", "ㅎ", "ㅗ", "ㅓ", "ㅏ", "ㅣ", ";"],
                  ["ㅋ", "ㅌ", "ㅊ", "ㅍ", "ㅠ", "ㅜ", "ㅡ", ",", ".", "/"]]

#반복문 쓸라고 만든 임의의 변수
i=0
i2=0
n=0
nn=1

#한영키 토클키 초기값 0 ENG
togglekey = 0
BT_togglekey=0

prevTime = 0

while cap.isOpened():
    ret, img = cap.read()   #현재 영상을 받아 img 에 저장 잘받았으면 ret에 참 저장
    
    curTime = time.time()
    sec = curTime - prevTime
    prevTime = curTime
    fps = 1/(sec)
    print("fps {0} " . format(fps))

    if not ret: #참 아니면 건너뛰기
        continue
    
    #좌우반전
    img = cv2.flip(img, 1)
    #opencv 는 BGR컬러 시스템 이용 
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    #전처리
    result = hands.process(img)
    #mediapipe 는 RGB 컬러 시스템 이용
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

#     
#             #한글 띄우는거@@@@@@@- 같이다녀야함!      PIL(pillow)
#             img = Image.fromarray(img)    
#             draw = ImageDraw.Draw(img)
#             draw.text(xy=(100, 100),  text="text ", font=font, fill=(255, 255, 255))
#             img = np.array(img)
    
    #손 뜬다면 밑으로
    if result.multi_hand_landmarks is not None:

#-----------------------------손 각도 계산하고 클릭하는 for 문 START-------------------------------------------

        for res in result.multi_hand_landmarks:
            joint = np.zeros((21, 3))
            for j, lm in enumerate(res.landmark):
                joint[j] = [lm.x, lm.y, lm.z]

            #엄지끝
            thumb=joint[4]
            #검지끝
            index=joint[8]
            #중지끝
            MIDDLE_FINGER_TIP=joint[12]

            # Compute angles between joints
            v1 = joint[[0,1,2,3,0,5,6,7,0,9,10,11,0,13,14,15,0,17,18,19],:] # Parent joint
            v2 = joint[[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],:] # Child joint
            v = v2 - v1 # [20,3]
            # Normalize v
            v = v / np.linalg.norm(v, axis=1)[:, np.newaxis]

            # Get angle using arcos of dot product
            angle = np.arccos(np.einsum('nt,nt->n',
                v[[0,1,2,4,5,6,8,9,10,12,13,14,16,17,18],:],
                v[[1,2,3,5,6,7,9,10,11,13,14,15,17,18,19],:])) # [15,]

            angle = np.degrees(angle) # Convert radian to degree

            # Inference gesture
            data = np.array([angle], dtype=np.float32)
            ret, results, neighbours, dist = knn.findNearest(data, 3)
            idx = int(results[0][0])

            
            #음성인식
            if BT_togglekey == 2:

                cv2.putText(img, "Voice_Recognition", org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
                img = Image.fromarray(img)    
                draw = ImageDraw.Draw(img)
                draw.text(xy=(275, 515),  text="키보드BT", font=font, fill=(255, 255, 255))
                draw.text(xy=(495, 515),  text="음성인식 프로그램켜기", font=font, fill=(255, 255, 255))
                draw.text(xy=(815, 515),  text="마우스BT", font=font, fill=(255, 255, 255))
                #얘는 항상 마지막에
                img = np.array(img)
                # 340,460 480,700 720 840
                cv2.rectangle(img,(260,500),(380,550),(255,0,0),2)
                cv2.rectangle(img,(480,500),(700,550),(255,0,0),2)
                cv2.rectangle(img,(800,500),(920,550),(255,0,0),2)
                
                #음성인식 실행
                # if n==1 :
                #     voice = voiceloop()
                #     voice.start()
                #     n=0
                    
                diff_x = abs(index[0] - thumb[0])
                diff_y=abs(index[1]-thumb[1])
                click=int(diff_x * 1000)
                click2=int(diff_y*1000)
                if click < touch_sensitivity and click2<touch_sensitivity:
                    if (260<(res.landmark[8].x*1280)<380) and 500<(res.landmark[8].y*700)<550: 
                        if n==0:
                            BT_togglekey=0
                            n=1
                        #time.sleep(0.15)
                    elif (480<(res.landmark[8].x*1280)<700) and 500<(res.landmark[8].y*700)<550:
                        #time.sleep(0.15)
                        #한번만 실행
                        if threading.active_count() == 1:
                            voice = voiceloop()
                            voice.start()
                            # voice.join
                    elif (800<(res.landmark[8].x*1280)<920) and 500<(res.landmark[8].y*700)<550:
                        if n==0:
                            BT_togglekey=1
                            n=1
                        #time.sleep(0.15)
                else :
                    n=0
            #마우스
            if BT_togglekey == 1:
                max_num_hands = 1
                cv2.putText(img, "Mouse", org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
                img = Image.fromarray(img)    
                draw = ImageDraw.Draw(img)
                draw.text(xy=(420, 510),  text="키보드BT", font=font, fill=(255, 255, 255))
                draw.text(xy=(690, 510),  text="음성인식BT", font=font, fill=(255, 255, 255))
                #얘는 항상 마지막에
                img = np.array(img)
                cv2.rectangle(img,(400,500),(520,550),(255,0,0),2)
                cv2.rectangle(img,(680,500),(800,550),(255,0,0),2)
                                
                #현제 해상도 만큼 움직이기위해 1920 * 1080
                # pyautogui 로 마우스를 움직이면 렉먹습니다.
                # pyautogui.moveTo(int(res.landmark[8].x*1920),(res.landmark[8].y*1080))
                # originalx = res.landmark[8].x*1280
                # originaly = res.landmark[8].y*700
                #pynput 에 있는 마우스 이동 함수로 구현 하니 렉 해결
                
                # 이동할 movex,movey 값 변수 만들기
                # 현제 x,y값 res.landmark[8].x*1280 , res.landmark[8].y*700
                # print('현재 마우스 포지션: {0}'.format(mouse_drag.position))
                mouse_drag.position=(res.landmark[8].x*1920,res.landmark[8].y*1080) 
                
                # print('바뀐 마우스 포지션: {0}'.format(mouse_drag.position))
                diff__x = abs(MIDDLE_FINGER_TIP[0] - index[0])
                diff__y = abs(MIDDLE_FINGER_TIP[1] - index[1])
                mouse_click=int(diff__x * 1000)
                mouse_click2=int(diff__y * 1000)
                # if idx == 2:
                
                if mouse_click < touch_sensitivity and mouse_click2 < touch_sensitivity + touch_sensitivity_plus:
                    if nn==1 :
                        mouse_drag.press(Button.left)
                        touch_sensitivity_plus += 10
                        nn=0
                else :
                        if nn == 0:
                            touch_sensitivity_plus -= 10
                        mouse_drag.release(Button.left)
                        nn=1

                diff_x = abs(index[0] - thumb[0])
                diff_y=abs(index[1]-thumb[1])
                click=int(diff_x * 1000)
                click2=int(diff_y*1000)
                if click < touch_sensitivity and click2<touch_sensitivity:
                    if (400<(res.landmark[8].x*1280)<520) and 500<(res.landmark[8].y*700)<550: 
                        if n==0 :
                            BT_togglekey=0
                            max_num_hands = 2
                            n=1
                        #time.sleep(0.15)
                    elif (680<(res.landmark[8].x*1280)<800) and 500<(res.landmark[8].y*700)<550: 
                        if n==0:
                            BT_togglekey=2
                            max_num_hands = 2
                            n=1
                        #time.sleep(0.15)
                else :
                    n=0
            # Draw gesture result 키보드 클릭부분
            if BT_togglekey == 0:
                # if idx in  rps_gesture.keys():    text=rps_gesture[idx].upper()
                # cv2.putText(img,"Keyboard", org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
                
                diff_x = abs(index[0] - thumb[0])
                diff_y=abs(index[1]-thumb[1])
                click=int(diff_x * 1000)
                click2=int(diff_y*1000)
                if click < touch_sensitivity and click2<touch_sensitivity:
                    if togglekey == 0: #영어 클릭
                        for i in range(len(keyboard_keys)):
                            for i2 in range(len(keyboard_keys[i])):
                                if (kb_start_x+(120*i2)<(res.landmark[8].x*1280)<kb_end_x+(120*i2)) and (kb_start_y+(120*i)<(res.landmark[8].y*700)<kb_end_y+(120*i)):
                                    # pyautogui.press(keyboard_keys[i][i2])
                                    if n==0:
                                        print('click')
                                        keyboard.press(keyboard_keys[i][i2])
                                        keyboard.release(keyboard_keys[i][i2])
                                        n=1
                    if togglekey == 1:  #한글 클릭
                        for i in range(len(keyboard_keys_KOR)):
                            for i2 in range(len(keyboard_keys_KOR[i])):
                                if (kb_start_x+(120*i2)<(res.landmark[8].x*1280)<kb_end_x+(120*i2)) and (kb_start_y+(120*i)<(res.landmark[8].y*700)<kb_end_y+(120*i)):
                                    if n==0:
                                        print('click')
                                        keyboard.press(keyboard_keys[i][i2])
                                        keyboard.release(keyboard_keys[i][i2])
                                        n=1

                    #한/영키 클릭
                    if (50<(res.landmark[8].x*1280)<150) and 180<(res.landmark[8].y*700)<230:
                        if n==0:
                            print('click')
                            if togglekey == 0:
                                togglekey=1
                                n=1
                                #time.sleep(0.15)
                            else:
                                togglekey=0
                                n=1
                                #time.sleep(0.15)

                    #키보드 버튼 클릭
                    if (290<(res.landmark[8].x*1280)<390) and 180<(res.landmark[8].y*700)<230: 
                        if n==0:
                            BT_togglekey=0
                            n=1
                        #time.sleep(0.2)
                    #마우스 버튼 클릭
                    elif (170<(res.landmark[8].x*1280)<270) and 180<(res.landmark[8].y*700)<230:
                        if n==0:
                            BT_togglekey=1
                            n=1
                        #time.sleep(0.2)
                    #음성인식 버튼 클릭
                    elif (410<(res.landmark[8].x*1280)<510) and 180<(res.landmark[8].y*700)<230: 
                        if n==0:
                            BT_togglekey=2
                            n=1
                        #time.sleep(0.2)
                    #space바
                    elif (770<(res.landmark[8].x*1280)<990) and 180<(res.landmark[8].y*700)<280: 
                        if n==0:
                            keyboard.press(Key.space)
                            keyboard.release(Key.space)
                            n=1
                        #time.sleep(0.2)
                    #백스페이스
                    elif (1010<(res.landmark[8].x*1280)<1230) and 180<(res.landmark[8].y*700)<280: 
                        if n==0:
                            keyboard.press(Key.backspace)
                            keyboard.release(Key.backspace)
                            n=1
                        #time.sleep(0.2)
                    
                else :
                    n =0
            # Other gestures
            # cv2.putText(img, text=gesture[idx].upper(), org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)

            mp_drawing.draw_landmarks(img, res, mp_hands.HAND_CONNECTIONS,mp_drawing_styles.get_default_hand_landmarks_style(),mp_drawing_styles.get_default_hand_connections_style())
            
#-----------------------------손 각도 계산하고 클릭하는 for 문 END-------------------------------------------

            # 검지좌표 찍어주는 코드 (검지에 x 값 손바닥에 검지y 값)
            # 8번 랜드마크.x 좌표에 1280곱해서 해상도만큼 올려서 x 좌표구함
            # res.landmark[8].x*1280
            # cv2.putText(img, str(res.landmark[8].x*1280), org=(int(res.landmark[8].x * img.shape[1]), int(res.landmark[8].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
            # cv2.putText(img, str(res.landmark[8].y*720), org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)
           
#-----------------------------한글 그리기 START-------------------------------------------
    if BT_togglekey ==0:
            if togglekey == 0:
                img = Image.fromarray(img)   
                draw = ImageDraw.Draw(img)
                draw.text(xy=(70, 200),  text="한/영", font=font, fill=(255, 255, 255))
                draw.text(xy=(190, 200),  text="마우스", font=font, fill=(255, 255, 255))
                draw.text(xy=(310, 200),  text="키보드", font=font, fill=(255, 255, 255))
                draw.text(xy=(420, 200),  text="음성인식", font=font, fill=(255, 255, 255))
                img = np.array(img)
            else:
                img = Image.fromarray(img)   
                draw = ImageDraw.Draw(img)
                draw.text(xy=(70, 200),  text="한/영", font=font, fill=(255, 255, 255))
                draw.text(xy=(190, 200),  text="마우스", font=font, fill=(255, 255, 255))
                draw.text(xy=(310, 200),  text="키보드", font=font, fill=(255, 255, 255))
                draw.text(xy=(420, 200),  text="음성인식", font=font, fill=(255, 255, 255))
                for i in range(len(keyboard_keys_KOR)):
                    for i2 in range(len(keyboard_keys_KOR[i])):
                        draw.text(xy=(kb_text_x+(120*i2),kb_text_y-(20)+(120*i)),  text=str(keyboard_keys_KOR[i][i2]), font=ImageFont.truetype('{}/fonts/SCDream6.otf'.format(path), 25), fill=(255, 255, 255))
                        
                #얘는 항상 마지막에
                img = np.array(img)
                if result.multi_hand_landmarks is not None:
                            for res in result.multi_hand_landmarks:
                                if (kb_start_x+(120*i2)<(res.landmark[8].x*1280)<kb_end_x+(120*i2)) and (kb_start_y+(120*i)<(res.landmark[8].y*700)<kb_end_y+(120*i)):
                                    cv2.rectangle(img,(kb_start_x+(120*i2),kb_start_y+(120*i)),(kb_end_x+(120*i2),kb_end_y+(120*i)),(0,0,255),2)

#-----------------------------한글 그리기 END-------------------------------------------

#-----------------------------키보드 그려주기 START-------------------------------------------

           # 손 보이면 키보드 그려주기 계속 보이고 싶으면 if 문 밖으로 빼면됨.
    if BT_togglekey ==0:
            if togglekey == 0:
                cv2.putText(img, "space", (890,210), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                cv2.putText(img, "backspace", (1060,210), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                cv2.putText(img, "<-", (1170,250), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                for i in range(len(keyboard_keys)):
                    for i2 in range(len(keyboard_keys[i])):
                        cv2.rectangle(img,(kb_start_x+(120*i2),kb_start_y+(120*i)),(kb_end_x+(120*i2),kb_end_y+(120*i)),(255,0,0),2)
                        cv2.putText(img, str(keyboard_keys[i][i2]), (kb_text_x+(120*i2),kb_text_y+(120*i)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                            
                        #한영키,각종BT
                        draw_rec(img)

                        #검지 닿으면 빨갛게 변하게
                        if result.multi_hand_landmarks is not None:
                            for res in result.multi_hand_landmarks:
                                if (kb_start_x+(120*i2)<(res.landmark[8].x*1280)<kb_end_x+(120*i2)) and (kb_start_y+(120*i)<(res.landmark[8].y*700)<kb_end_y+(120*i)):
                                    cv2.rectangle(img,(kb_start_x+(120*i2),kb_start_y+(120*i)),(kb_end_x+(120*i2),kb_end_y+(120*i)),(0,0,255),2)
                            
            else :
                cv2.putText(img, "space", (890,210), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                cv2.putText(img, "backspace", (1060,210), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                cv2.putText(img, "<-", (1170,250), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                for i in range(len(keyboard_keys_KOR)):
                    for i2 in range(len(keyboard_keys_KOR[i])):
                        cv2.rectangle(img,(kb_start_x+(120*i2),kb_start_y+(120*i)),(kb_end_x+(120*i2),kb_end_y+(120*i)),(255,0,0),2)
                        
                        # 한글이 안나오는 관계로 위 한글그리기 코드로 대체
                        # cv2.putText(img, str(keyboard_keys_KOR[i][i2]), (kb_text_x+(70*i2),kb_text_y+(70*i)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
                            
                        #한영키, 각종BT
                        draw_rec(img)
                            
                        if result.multi_hand_landmarks is not None:
                            for res in result.multi_hand_landmarks:
                                if (kb_start_x+(120*i2)<(res.landmark[8].x*1280)<kb_end_x+(120*i2)) and (kb_start_y+(120*i)<(res.landmark[8].y*700)<kb_end_y+(120*i)):
                                    cv2.rectangle(img,(kb_start_x+(120*i2),kb_start_y+(120*i)),(kb_end_x+(120*i2),kb_end_y+(120*i)),(0,0,255),2)

#-----------------------------키보드 그려주기 END-------------------------------------------

    cv2.imshow('Virtual keyboard Mouse', img)
    #q 누르면 종료
    if cv2.waitKey(1) == ord('q'):
        break
from pynput.keyboard import Controller
import os
import threading
import speech_recognition as sr
# import keyboard

class voiceloop(threading.Thread):
    
    mykeyboard = Controller()
    
    def run(self):
        while True:
            voice = self.CollectVoice()
            if voice != False:
                print(voice)
                self.Pasting(voice)
                break
        

    def Pasting(self, myvoice):
        for character in myvoice:
            self.mykeyboard.type(character)
        self.mykeyboard.type(" ")

    def CollectVoice(self):
        #get microphone device on notebook or desk top
        listener = sr.Recognizer()
        voice_data = ""
        
        with sr.Microphone() as raw_voice:
            
            try:
                print("Adjusting")
                listener.adjust_for_ambient_noise(raw_voice)
                
                #adjust setting values
                listener.dynamic_energy_adjustment_damping=0.2
                listener.pause_threshold = 0.6
                listener.energy_threshold = 600
                
                print("Say something!")
                audio = listener.listen(raw_voice)
                voice_data = listener.recognize_google(audio, language='ko')
                
            except UnboundLocalError:
                pass
            
            except sr.UnknownValueError:
                print("could not understand audio")
                return False
            
            return str(voice_data)

    # def on_closing():
    #     print("finish work")
    #     #myThread.join()
    #     os._exit(1)

if __name__ == "__main__":
    myThread = voiceloop()
    myThread.start()